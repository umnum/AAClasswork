require 'rails_helper'

RSpec.describe SessionsController, type: :controller do
    # describe 'GET #NEW' do
    #     it 'renders login form' do
    #         get :new
    #         expect(response).to render_template(:new)
    #     end
    # end

    # describe 'POST #CREATE' do
    #     let(:user_params) do{
    #         user: {
    #             username: "cappy",
    #             password: "password"
    #         }
    #     }
    #     end
    #     it 'logs in user' do
    #         cappy= User.create!(user_params)
    #         post :create, params: user_params
    #         user = User.find_by(username: "cappy")
    #         expect(session[:session_token]).to eq(user.session_token)
    #     end 
    # end

    # describe 'DELETE #DESTROY' do
    #     it 'logs user out'
    # end 
end
