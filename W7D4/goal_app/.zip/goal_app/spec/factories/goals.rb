FactoryBot.define do
  factory :goal do
    
  end
end
